﻿
using System;
using System.Collections;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-03-22
 */

namespace ConsoleApp.MaCrizzaLynne.Regacho
{
    internal class Program
    {

        static void Main(string[] args)
        {
            #region Previous Assignments
            VehicleQuote quote1;


            Vehicle vehicle1 = new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 20000m);
            quote1 = new VehicleQuote(0.05m, vehicle1, 0m);


            Console.WriteLine("SalePrice: " + quote1.SalePrice.ToString("C"));
            Console.WriteLine("TaxRate: " + quote1.TaxRate);


            Console.WriteLine(quote1.ToString());


            VehicleQuote quote2;
            Vehicle vehicle2 = new Vehicle(2012, "Honda", "Civic", PaintColor.Aquamarine, 22000m);
            quote2 = new VehicleQuote(0.07m, vehicle2, 0m);


            quote2.SalePrice = 14000m;
            quote2.TaxRate = 0.049m;


            List<Vehicle> vehicles;


            vehicles = new List<Vehicle>();


            vehicles.Add(new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 20000m));
            vehicles.Add(new Vehicle(2012, "Honda", "Civic", PaintColor.Aquamarine, 22000m));
            vehicles.Add(new Vehicle(2015, "Ford", "Focus", PaintColor.Black, 24000m));


            Console.WriteLine("Number of vehicles: " + vehicles.Count);


            foreach (Vehicle CurrentVehicle in vehicles)
            {
                Console.WriteLine(CurrentVehicle.ToString());

            }



            Vehicle vehicle;


            vehicle = new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 33000m);


            VehicleQuote vehicleQuote;


            vehicleQuote = new VehicleQuote(0.0199m, vehicle, 3000m);


            VehicleOption vehicleOption = new VehicleOption("Custom Headlight", 500m, 2);


            vehicleQuote.AddOption(vehicleOption);


            vehicleQuote.AddOption(new VehicleOption("Decal", 100m, 1));
            vehicleQuote.AddOption(new VehicleOption("Bluetooth Stereo", 900m, 1));


            PrintQuoteDetails(vehicleQuote);


            vehicleQuote.RemoveOption(vehicleOption);


            Console.WriteLine("Number of options: " + vehicleQuote.GetOptions().Count);

            Console.ReadKey();

            #endregion


            // 1. Declare and define a variable that references a VehicleQuote object. 
            Vehicle vehicle3 = new Vehicle(2011, "Ford", "Focus", PaintColor.Sienna, 25000m);
            VehicleQuote vehicleQuote3 = new VehicleQuote(0.0199m, vehicle2, 2000m);



            // 2. Define a method in this class that handles the event that occurs when the sale price changes.
            //    The handler method will print: "The sale price changed to {sale-price}."
            //    Subscribe to the event below using the handler method you just defined.
            //    Step 4: Subscribe to the events
            vehicleQuote3.SalePriceChanged += VehicleQuote3_SalePriceChanged;


            // 3. Define a method in this class that handles the event that occurs when an option is added to the quote.
            //    The handler method will print: "The following option was added to the quote:\n{vehicle-option}" 
            //    Subscribe to the event below using the handler method you just defined.
            vehicleQuote3.VehicleOptionAdded += VehicleQuote3_VehicleOptionAdded;



            // 4. Define a method in this class that handles the event that occurs when trade-in value has been changed.
            //    The handler method will print "The trade-in value has been changed."
            //    Subscribe to the event below using the handler method you just defined. 
            vehicleQuote3.TradeInValueChanged += VehicleQuote3_TradeInValueChanged;



            // 5. Declare and define a variable to reference a new instance of the VehicleOption class.
            VehicleOption vehicleOption3 = new VehicleOption("Toyota", 70000m, 2);



            // 6. Add the VehicleOption created in the previous statement to the options of the
            //    VehicleQuote instance.
            vehicleQuote3.AddOption(vehicleOption3);



            // 7. Add two more VehicleOption objects to the VehicleQuote instance. Only use two statements
            //    to accomplish this step.
            vehicleQuote3.AddOption(new VehicleOption("Bluetooth Audio System", 8000m, 1));
            vehicleQuote3.AddOption(new VehicleOption("Sunroof", 1500m, 1));



            // 8. Change the sale price of the VehicleQuote to a different value than its current state.
            vehicleQuote3.SalePrice = 149500m;



            // 9. Add another VehicleOption to the VehicleQuote.
            vehicleQuote3.AddOption(new VehicleOption("Heated Seats", 7000m, 2));



            // 10. Change the trade-in value of the VehicleQuote to a different value than its current state.
            vehicleQuote3.TradeInValue = 3000m;



            // 11. Repeat the previous statement.
            vehicleQuote3.TradeInValue = 4000m;



            Console.WriteLine("\nPress a key to continue");
            Console.ReadKey();

        }



        // 4. Define a method in this class that handles the event that occurs when trade-in value has been changed.
        //    The handler method will print "The trade-in value has been changed."
        private static void VehicleQuote3_TradeInValueChanged(object sender, EventArgs e)
        {
            Console.WriteLine("\nThe trade-in value has been changed.");
        }



        // 3. Define a method in this class that handles the event that occurs when an option is added to the quote.
        //    The handler method will print: "The following option was added to the quote:\n{vehicle-option}"
        //    Step 5: Handle the event

        private static void VehicleQuote3_VehicleOptionAdded(object sender, EventArgs e)
        {
            VehicleOptionAddedEventArgs eventArgs = (VehicleOptionAddedEventArgs)e;

            Console.WriteLine($"\nThe following option was added to the quote:\n{eventArgs.VehicleOption.ToString()}");

        }

        // 2. Define a method in this class that handles the event that occurs when the sale price changes.
        //    The handler method will print: "The sale price changed to {sale-price}."
        //    Step 5: Handle the event

        private static void VehicleQuote3_SalePriceChanged(object sender, EventArgs e)
        {
            Console.WriteLine("\nThe sale price changed to {0:C}.", ((VehicleQuote)sender).SalePrice);
        }

        #region Previous Assignment

        static void PrintQuoteDetails(VehicleQuote quote)
        {
            Console.WriteLine("Vehicle sale price: {0:C}", quote.Vehicle.SalePrice);
            Console.WriteLine("Options:");
            foreach (var option in quote.GetOptions())
            {
                Console.WriteLine("\t{0} x {1} @ {2:C}", option.Description, option.Quantity, option.UnitPrice);
            }
            Console.WriteLine("Subtotal: {0:C}", quote.GetSubtotal());
            Console.WriteLine("Sales tax: {0:C}", quote.CalculateSalesTax());
            Console.WriteLine("Total: {0:C}", quote.CalculateTotalQuote());
            Console.WriteLine("Trade-in value: -{0:C}", quote.TradeInValue);
            Console.WriteLine("Amount due: {0:C}", quote.GetAmountDue());
        }

        #endregion






    }
}