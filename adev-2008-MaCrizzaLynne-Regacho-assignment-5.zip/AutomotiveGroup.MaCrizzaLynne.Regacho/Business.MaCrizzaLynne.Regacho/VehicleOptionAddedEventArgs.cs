﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;


/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-03-20
 * Updated: 2024-03-22
 */


namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// Represents the Event Args for the OnVehicleOptionAdded custom event
    /// </summary>
    public class VehicleOptionAddedEventArgs : EventArgs
    {

        /// <summary>
        /// Gets or sets a VehicleOption
        /// </summary>
        public VehicleOption VehicleOption { get; set; }
    

        /// <summary>
        /// Initializes the VehicleOptionAdded Event
        /// </summary>
        /// <param name="vehicleOption"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public VehicleOptionAddedEventArgs(VehicleOption vehicleOption)
        {
            if (vehicleOption == null)
            {
                throw new ArgumentNullException("VehicleOption cannot be null.");
            }

            this.VehicleOption = vehicleOption;
        }

    }
}