﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Business.MaCrizzaLynne.Regacho;
using System.Collections.Generic;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-03-04
 * Updated: 2024-03-07
 */

namespace Test.Business.MaCrizzaLynne.Regacho
{
    #region Naming Convention for Unit Test Methods
    //naming convention for unit test methods:
    //{unit that your testing}_{test scenario}_{expected behaviour}

    //Testing steps
    //AAA Arrange: set up the details of the test
    //Act: invoke the scenario
    //Assert: verify the results 
    #endregion

    #region Constructor Methods

    [TestClass]
    public class VehicleQuoteTest
    {
        // VehicleQuote_ConstructorWithNegativeTaxRate_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_TaxRateIsLessThanZero_ThrowsException()
        {
            // Arrange
            decimal taxRate = -0.05m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, 20000m);

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => new VehicleQuote(taxRate, vehicle));

            // Assert exception state
            Assert.AreEqual("TaxRate", exception.ParamName);
            Assert.AreEqual("The TaxRate must be within the range of 0 to 1 (inclusive).", GetExceptionMessage(exception.Message));
        }


        // VehicleQuote_ConstructorWithTaxRateGreaterThanOne_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_TaxRateIsGreaterThanOne_ThrowsException()
        {
            // Arrange
            decimal taxRate = 1.05m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, 20000m);

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => new VehicleQuote(taxRate, vehicle));

            // Assert exception state
            Assert.AreEqual("TaxRate", exception.ParamName);
            Assert.AreEqual("The TaxRate must be within the range of 0 to 1 (inclusive).", GetExceptionMessage(exception.Message));
        }



        // VehicleQuote_ConstructorWithNullVehicle_ThrowsNullReferenceException
        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void Constructor_VehicleIsNull_ThrowsException()
        {
            // Arrange
            decimal taxRate = 0.05m;
            Vehicle vehicle = null;

            // Act
            VehicleQuote quote = new VehicleQuote(taxRate, vehicle, 0);

            // Assert
            // Not needed because the ExpectedException attribute is used
        }


        // VehicleQuote_ConstructorWithNegativeTradeInValue_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_TradeInValueIsLessThanZero_ThrowsException()
        {
            // Arrange
            decimal taxRate = 0.05m;
            decimal tradeInValue = -1m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, 20000m);

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => new VehicleQuote(taxRate, vehicle, tradeInValue));

            // Assert exception state
            Assert.AreEqual("tradeInValue", exception.ParamName);
            Assert.AreEqual("The trade-in value must be 0 or greater.", GetExceptionMessage(exception.Message));
        }


        // VehicleQuote_ConstructorWithOmittedTradeInValue_InitializesAttributes
        [TestMethod]
        public void Constructor_TradeInValueOmitted_InitializesAttributes()
        {
            // Arrange
            decimal expectedSalePrice = 20000m;
            decimal expectedTaxRate = 0.05m;
            decimal expectedTradeInValue = 0m;
            Vehicle expectedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, expectedVehicle);

            // Reflection
            PrivateObject target = new PrivateObject(quote);

            // Obtain object state
            Vehicle actualVehicle = (Vehicle)target.GetField("vehicle");
            decimal actualTradeInValue = (decimal)target.GetField("tradeInValue");
            decimal actualTaxRate = quote.TaxRate;
            decimal actualSalePrice = quote.SalePrice;
            object actualOptions = target.GetField("options");

            // Assert
            Assert.AreEqual(expectedVehicle, actualVehicle);
            Assert.AreEqual(expectedTradeInValue, actualTradeInValue);
            Assert.AreEqual(expectedTaxRate, actualTaxRate);
            Assert.AreEqual(expectedSalePrice, actualSalePrice);
            Assert.IsNotNull(actualOptions);
        }

        // VehicleQuote_Constructor_InitializesAttributes
        [TestMethod]
        public void Constructor_InitializesAttributes()
        {
            // Arrange
            decimal expectedSalePrice = 20000m;
            decimal expectedTaxRate = 0.05m;
            decimal expectedTradeInValue = 0m;
            Vehicle expectedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, expectedVehicle);

            // Reflection
            PrivateObject target = new PrivateObject(quote);

            // Obtain object state
            Vehicle actualVehicle = (Vehicle)target.GetField("vehicle");
            decimal actualTradeInValue = (decimal)target.GetField("tradeInValue");
            decimal actualTaxRate = (decimal)target.GetProperty("TaxRate");
            decimal actualSalePrice = (decimal)target.GetProperty("SalePrice");
            object actualOptions = target.GetField("options");

            // Assert
            Assert.AreEqual(expectedVehicle, actualVehicle);
            Assert.AreEqual(expectedTradeInValue, actualTradeInValue);
            Assert.AreEqual(expectedTaxRate, actualTaxRate);
            Assert.AreEqual(expectedSalePrice, actualSalePrice);
            Assert.IsNotNull(actualOptions);
        }

        #endregion

    #region Sale Price Property Method
        // VehicleQuote_SalePriceProperty_ReturnsCorrectState
        [TestMethod]
        public void SalePriceProperty_ReturnState()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal expectedSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            decimal salePriceProperty = quote.SalePrice;

            // Assert
            Assert.AreEqual(expectedSalePrice, salePriceProperty);
        }

        // VehicleQuote_SalePriceProperty_SetToLessThanZero_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void SalePriceProperty_SalePriceLessThanZero_ThrowsException()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);

            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(
                () => quote.SalePrice = -1m);

            // Assert
            Assert.AreEqual("SalePrice", exception.ParamName);
            Assert.AreEqual("The SalePrice must be greater than 0.", GetExceptionMessage(exception.Message));
        }

        // VehicleQuote_SalePriceProperty_SetToZero_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void SalePriceProperty_SalePriceEqualToZero_ThrowsException()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);

            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(
                () => quote.SalePrice = 0m);

            // Assert
            Assert.AreEqual("SalePrice", exception.ParamName);
            Assert.AreEqual("The SalePrice must be greater than 0.", GetExceptionMessage(exception.Message));
        }

        // Vehicle_SalePriceProperty_Updated_ReturnsUpdatedState
        [TestMethod]
        public void SalePriceProperty_UpdateState()
        {
            // Arrange
            decimal initialSalePrice = 20000m;
            decimal updatedSalePrice = 25000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);

            // Act
            Vehicle updatedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, updatedSalePrice);

            // Reflection
            PrivateObject target = new PrivateObject(updatedVehicle);

            // Obtain object state
            decimal actualSalePrice = (decimal)target.GetField("salePrice");

            // Assert
            Assert.AreEqual(updatedSalePrice, actualSalePrice);
        }
        #endregion

    #region Vehicle Property Method


        // VehicleQuote_VehicleProperty_Accessed_ReturnsCorrectState
        [TestMethod]
        public void VehicleProperty_ReturnState()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal expectedSalePrice = 20000m;
            Vehicle expectedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, expectedVehicle);
            Vehicle vehicleFromQuote = quote.Vehicle;

            // Assert
            Assert.AreEqual(expectedVehicle, vehicleFromQuote);
        }

        // VehicleQuote_VehicleProperty_SetToNull_ThrowsArgumentNullException
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void VehicleProperty_SetToNull_ThrowsException()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal expectedSalePrice = 20000m;
            Vehicle expectedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, expectedVehicle);

            // Act
            quote.Vehicle = null;

            //Assert
            //Not needed
        }

        // VehicleQuote_VehicleProperty_Updated_ReturnsUpdatedState
        [TestMethod]
        public void VehicleProperty_UpdateState()
        {
            // Arrange
            decimal taxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            decimal updatedSalePrice = 25000m;
            Vehicle initialVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(taxRate, initialVehicle);

            // Act
            Vehicle updatedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, updatedSalePrice);
            quote.Vehicle = updatedVehicle;

            // Reflection
            PrivateObject quotePrivateObject = new PrivateObject(quote);
            Vehicle actualVehicle = (Vehicle)quotePrivateObject.GetField("vehicle");

            // Obtain object state
            PrivateObject vehiclePrivateObject = new PrivateObject(actualVehicle);
            decimal actualSalePrice = (decimal)vehiclePrivateObject.GetField("salePrice");

            // Assert
            Assert.AreEqual(updatedSalePrice, actualSalePrice);
        }
        #endregion

    #region Trade-in Value Property Method


        // VehicleQuote_TradeInValueProperty_Accessed_ReturnsCorrectState
        [TestMethod]
        public void TradeInValueProperty_ReturnState()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal expectedSalePrice = 20000m;
            decimal expectedTradeInValue = 5000m;
            Vehicle expectedVehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, expectedSalePrice);

            // Act
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, expectedVehicle, expectedTradeInValue);
            decimal tradeInValueFromQuote = quote.TradeInValue;

            // Assert
            Assert.AreEqual(expectedTradeInValue, tradeInValueFromQuote);
        }


        // VehicleQuote_TradeInValueProperty_SetToLessThanZero_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void SetTradeInValue_ToValueLessThanZero_ThrowsException()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            decimal initialTradeInValue = quote.TradeInValue;

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => quote.TradeInValue = -1m);

            // Assert exception state
            Assert.AreEqual("value", exception.ParamName);
            Assert.AreEqual("The value must be 0 or greater.", GetExceptionMessage(exception.Message));

            // Reflection
            PrivateObject target = new PrivateObject(quote);

            // Obtain object state
            decimal actual = (decimal)target.GetField("tradeInValue");

            // Assert
            Assert.AreEqual(initialTradeInValue, actual);
        }


        // VehicleQuote_TradeInValueProperty_Updated_ReturnsUpdatedState
        [TestMethod]
        public void TradeInValueProperty_UpdateState()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            decimal initialTradeInValue = 5000m;
            decimal updatedTradeInValue = 6000m;
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            quote.TradeInValue = initialTradeInValue;

            // Act
            quote.TradeInValue = updatedTradeInValue;

            // Reflection
            PrivateObject target = new PrivateObject(quote);

            // Obtain object state
            decimal actualTradeInValue = (decimal)target.GetField("tradeInValue");

            // Assert
            Assert.AreEqual(updatedTradeInValue, actualTradeInValue);
        }
        #endregion

    #region Add Option Method

        // VehicleQuote_AddOptionMethod_OptionIsNull_ThrowsException
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AddOption_OptionIsNull_ThrowsException()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);

            // Act
            quote.AddOption(null);

            // Assert
            // Not needed because of ExpectedException attribute
        }

        // VehicleQuote_AddOptionMethod_OptionIsAdded_QuoteOptionsUpdated
        [TestMethod]
        public void AddOption_OptionIsAdded_QuoteOptionsUpdated()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            int quantity = 1;
            VehicleOption optionToAdd = new VehicleOption("Leather seats", 500m, quantity);
            int itemAddedSuccessfully = 1;

            // Act
            quote.AddOption(optionToAdd);

            // Assert
            PrivateObject privateObject = new PrivateObject(quote);
            Assert.AreEqual(itemAddedSuccessfully, ((List<VehicleOption>)privateObject.GetField("options")).Count);
        }

        #endregion

    #region Remove Option Method

        // VehicleQuote_RemoveOptionMethod_OptionIsRemoved_QuoteOptionsUpdated
        [TestMethod]
        public void RemoveOption_OptionIsRemoved_QuoteOptionsUpdated()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            int quantity = 1;
            VehicleOption optionToRemove = new VehicleOption("Leather seats", 500m, quantity);

            // Add to a local list
            List<VehicleOption> optionsList = new List<VehicleOption>() { optionToRemove };

            // Create a private object
            PrivateObject privateObject = new PrivateObject(quote);
            privateObject.SetField("options", optionsList);

            // Act
            quote.RemoveOption(optionToRemove);

            // Assert
            Assert.AreEqual(0, ((List<VehicleOption>)privateObject.GetField("options")).Count);
        }
        #endregion

    #region Get Options Method

        // VehicleQuote_GetOptionsMethod_ReturnsCopyOfQuoteOptions
        [TestMethod]
        public void GetOptions_CopyOfQuoteOptions()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            int quantity = 1;
            VehicleOption option1 = new VehicleOption("Leather seats", 500m, quantity);
            VehicleOption option2 = new VehicleOption("Heated seats", 300m, quantity);
            quote.AddOption(option1);
            quote.AddOption(option2);

            // Act
            PrivateObject privateObject = new PrivateObject(quote);
            List<VehicleOption> options = (List<VehicleOption>)privateObject.GetField("options");

            // Call the GetOptions method to get a copy of the options
            List<VehicleOption> optionsList = quote.GetOptions();

            // Assert
            Assert.AreEqual(options.Count, optionsList.Count);
        }
        #endregion

    #region Get Total Options Method

        // VehicleQuote_GetOptionsTotalMethod_ReturnsTotalCostOfQuoteOptions
        [TestMethod]
        public void GetOptionsTotal_ReturnsTotalCostOfQuoteOptions()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            int quantity = 1;
            VehicleOption option1 = new VehicleOption("Leather seats", 500m, quantity);
            VehicleOption option2 = new VehicleOption("Heated seats", 300m, quantity);
            quote.AddOption(option1);
            quote.AddOption(option2);
            decimal expectedTotalOptionsCost = (option1.UnitPrice * quantity) + (option2.UnitPrice * quantity);

            // Act
            decimal totalOptionsCost = quote.GetOptionsTotal();

            // Assert
            Assert.AreEqual(expectedTotalOptionsCost, totalOptionsCost);
        }
        #endregion

    #region Get Subtotal Method

        // VehicleQuote_GetSubTotalMethod_ReturnsCorrectSubtotal
        [TestMethod]
        public void GetSubtotal_ReturnsCorrectSubtotal()
        {
            // Arrange
            decimal expectedTaxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(expectedTaxRate, vehicle);
            int quantity = 1;
            VehicleOption option1 = new VehicleOption("Leather seats", 500m, quantity);
            VehicleOption option2 = new VehicleOption("Heated seats", 300m, quantity);
            quote.AddOption(option1);
            quote.AddOption(option2);
            decimal expectedSubtotal = initialSalePrice + (option1.UnitPrice * quantity) + (option2.UnitPrice * quantity);

            // Act
            decimal subtotal = quote.GetSubtotal();

            // Assert
            Assert.AreEqual(expectedSubtotal, subtotal);
        }
        #endregion

    #region Get Sale Tax Method

        // VehicleQuote_CalculateSalesTaxMethod_ReturnsCorrectSalesTax
        [TestMethod]
        public void CalculateSalesTax_ReturnsCorrectSalesTax()
        {
            // Arrange
            Vehicle vehicle = new Vehicle(2022, "Model", "Manufacturer", new PaintColor(), 10000m);
            VehicleQuote vehicleQuote = new VehicleQuote(0.05m, vehicle);
            VehicleOption vehicleOption = new VehicleOption("Option", 500m, 2);
            vehicleQuote.AddOption(vehicleOption);

            // Act
            decimal salesTax = vehicleQuote.CalculateSalesTax();

            // Assert
            Assert.AreEqual(550m, salesTax);
        }
        #endregion

    #region Get Total Method

        // VehicleQuote_GetTotalMethod_ReturnsCorrectTotal
        [TestMethod]
        public void GetTotal_ReturnsCorrectTotal()
        {
            // Arrange
            decimal taxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(taxRate, vehicle);
            int quantity = 1;
            VehicleOption option1 = new VehicleOption("Leather seats", 500m, quantity);
            VehicleOption option2 = new VehicleOption("Heated seats", 300m, quantity);
            quote.AddOption(option1);
            quote.AddOption(option2);
            decimal expectedSubtotal = initialSalePrice + (option1.UnitPrice * quantity) + (option2.UnitPrice * quantity);
            decimal expectedTotal = expectedSubtotal + (expectedSubtotal * taxRate);

            // Act
            decimal total = quote.CalculateTotalQuote();

            // Assert
            Assert.AreEqual(expectedTotal, total);
        }
        #endregion

    #region Get Amount Due Method

        // VehicleQuote_GetAmountDueMethod_ReturnsCorrectAmount
        [TestMethod]
        public void GetAmountDue_ReturnsCorrectAmount()
        {
            // Arrange
            decimal taxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            decimal tradeInValue = 5000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(taxRate, vehicle, tradeInValue);
            int quantity = 1;
            VehicleOption option1 = new VehicleOption("Leather seats", 500m, quantity);
            VehicleOption option2 = new VehicleOption("Heated seats", 300m, quantity);
            quote.AddOption(option1);
            quote.AddOption(option2);
            decimal expectedSubtotal = initialSalePrice + (option1.UnitPrice * quantity) + (option2.UnitPrice * quantity);
            decimal expectedTotal = expectedSubtotal + (expectedSubtotal * taxRate);
            decimal expectedAmountDue = expectedTotal - tradeInValue;

            // Act
            decimal amountDue = quote.GetAmountDue();

            // Assert
            Assert.AreEqual(expectedAmountDue, amountDue);
        }

        #endregion

    #region ToString Method

        // VehicleQuote_ToStringMethod_ReturnsCorrectVehicleQuoteStringRepresentation
        [TestMethod]
        public void ToString_Returns_VehicleQuoteStringRepresentation()
        {
            // Arrange
            decimal taxRate = 0.05m;
            decimal initialSalePrice = 20000m;
            decimal tradeInValue = 5000m;
            Vehicle vehicle = new Vehicle(2020, "Corolla", "Toyota", PaintColor.Sienna, initialSalePrice);
            VehicleQuote quote = new VehicleQuote(taxRate, vehicle, tradeInValue);

            // Act
            string quoteString = quote.ToString();

            // Assert
            Assert.AreEqual("VehicleQuote: $16,000.00", quoteString);
        } 
        #endregion

    #region Helper Methods
        /// <summary>
        /// Helper method to obtain only the message from an Exception object.
        /// </summary>
        /// <param name="exceptionMessage">The Exception's Message state.</param>
        /// <returns>The Exception's message with the parameter omitted.</returns>
        /// <remarks>
        /// The Exception.Message property returns the Exception's message on line 1 and
        /// the parameter name on line 2. This method reads the first line and returns
        /// the message.
        /// </remarks>
        private string GetExceptionMessage(string exceptionMessage)
        {
            return new System.IO.StringReader(exceptionMessage).ReadLine();
        }
        #endregion
    }
}
