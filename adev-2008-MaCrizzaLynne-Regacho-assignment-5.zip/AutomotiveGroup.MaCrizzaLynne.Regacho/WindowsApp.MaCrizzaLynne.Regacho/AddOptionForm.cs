﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp.MaCrizzaLynne.Regacho
{
    internal class AddOptionForm : ACE.BIT.ADEV.Forms.AddOptionForm
    {
        /// <summary>
        /// The vehicle option created in the form.
        /// </summary>
        private VehicleOption CreatedOption;

        /// <summary>
        /// Retrieves the vehicle option created in the form.
        /// </summary>
        /// <returns>The created vehicle option.</returns>
        public VehicleOption RetrieveCreatedOption()
        { 
            return CreatedOption; 
        }

        /// <summary>
        /// Initializes a new instance of the AddOptionForm class.
        /// </summary>
        public AddOptionForm()
        {
            // Center the form to the parent form (QuoteForm)
            this.StartPosition = FormStartPosition.CenterParent;

            // Initialize the nudQuantity NumericUpDown control
            nudQuantity.Minimum = 1;
            nudQuantity.Maximum = 100;
            nudQuantity.ReadOnly = true;

            // Initialize the errorProvider
            errorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;
            errorProvider.SetIconPadding(nudQuantity, 3);
            errorProvider.SetIconPadding(txtDescription, 3);
            errorProvider.SetIconPadding(txtUnitPrice, 3);

            // Initialize the option to null
            CreatedOption = null;

            // Event subscription
            btnAdd.Click += BtnAdd_Click;
            btnCancel.Click += BtnCancel_Click;



        }

        /// <summary>
        /// Handles the Click event of the btnCancel control.
        /// </summary>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Click event of the btnAdd control.
        /// </summary>
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();



            if (string.IsNullOrWhiteSpace(txtDescription.Text)) 
            {
                errorProvider.SetError(txtDescription, "Description is required");
                return;
            }

            if (!decimal.TryParse(txtUnitPrice.Text, out decimal unitPrice) || unitPrice < 0)
            {
                errorProvider.SetError(txtUnitPrice, "Unit price is required and must be a positive number");
                return;
            }

            CreatedOption = new VehicleOption(txtDescription.Text, unitPrice, (int)nudQuantity.Value);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }


    }
}
