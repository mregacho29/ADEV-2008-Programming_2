﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp.MaCrizzaLynne.Regacho
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();


            lblImage.Click += lblImage_Click;
            btnOK.Click += btnOK_Click;
        }

        private void lblImage_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.tumblr.com/crizzalynnetheoneandonly-blog/747903920260644865/carcalculator-for-my-adev-2nd-term-2024?source=share");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
