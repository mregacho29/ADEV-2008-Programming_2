﻿namespace WindowsApp.MaCrizzaLynne.Regacho
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.lblImage = new System.Windows.Forms.Label();
            this.lblCopyright = new System.Windows.Forms.Label();
            this.lblVehiCostCaptorLabel = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblDescription = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblImage
            // 
            this.lblImage.Image = ((System.Drawing.Image)(resources.GetObject("lblImage.Image")));
            this.lblImage.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.lblImage.Location = new System.Drawing.Point(316, 115);
            this.lblImage.Margin = new System.Windows.Forms.Padding(0);
            this.lblImage.Name = "lblImage";
            this.lblImage.Size = new System.Drawing.Size(150, 150);
            this.lblImage.TabIndex = 0;
            this.lblImage.Click += new System.EventHandler(this.lblImage_Click);
            // 
            // lblCopyright
            // 
            this.lblCopyright.AutoSize = true;
            this.lblCopyright.Location = new System.Drawing.Point(106, 286);
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(265, 16);
            this.lblCopyright.TabIndex = 1;
            this.lblCopyright.Text = "Copyright © 2024 Ma Crizza Lynne Regacho";
            this.lblCopyright.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVehiCostCaptorLabel
            // 
            this.lblVehiCostCaptorLabel.AutoSize = true;
            this.lblVehiCostCaptorLabel.Font = new System.Drawing.Font("Swis721 BlkEx BT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehiCostCaptorLabel.Location = new System.Drawing.Point(24, 51);
            this.lblVehiCostCaptorLabel.Name = "lblVehiCostCaptorLabel";
            this.lblVehiCostCaptorLabel.Size = new System.Drawing.Size(422, 34);
            this.lblVehiCostCaptorLabel.TabIndex = 2;
            this.lblVehiCostCaptorLabel.Text = "VehiCostCaptor v1.0";
            this.lblVehiCostCaptorLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(215, 248);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(70, 25);
            this.btnOK.TabIndex = 3;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.Location = new System.Drawing.Point(27, 107);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(306, 123);
            this.lblDescription.TabIndex = 4;
            this.lblDescription.Text = resources.GetString("lblDescription.Text");
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(501, 329);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblVehiCostCaptorLabel);
            this.Controls.Add(this.lblCopyright);
            this.Controls.Add(this.lblImage);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximizeBox = false;
            this.Name = "AboutForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About VehiCostCaptor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblImage;
        private System.Windows.Forms.Label lblCopyright;
        private System.Windows.Forms.Label lblVehiCostCaptorLabel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblDescription;
    }
}