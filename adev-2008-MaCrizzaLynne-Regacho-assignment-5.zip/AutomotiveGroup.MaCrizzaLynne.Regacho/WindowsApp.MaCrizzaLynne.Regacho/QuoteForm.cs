﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp.MaCrizzaLynne.Regacho
{
    internal class QuoteForm : ACE.BIT.ADEV.Forms.QuoteForm
    {
        /// <summary>
        /// Set attributes
        /// </summary>
        private VehicleQuote Quote;
        private decimal TaxRate;

        /// <summary>
        /// Set the initial state of the QuoteForm
        /// </summary>
        public QuoteForm()
        {
            // Set the tax rate to 12%
            this.TaxRate = 0.12m;


            // Set the title of the form
            this.Text = "Vehicle Quote - Ma Crizza Lynne Regacho";


            // Set the start position of the form to the center of the screen
            this.StartPosition = FormStartPosition.CenterScreen;


            // Set the label for the sales tax
            this.lblTaxRate.Text = $"Tax ({TaxRate:P2}):";


            // Set the state of the NumericUpDown control for the trade-in value input
            this.nudTradeInValue.Minimum = 0;
            this.nudTradeInValue.Maximum = 1000000;
            this.nudTradeInValue.DecimalPlaces = 2;
            this.nudTradeInValue.Increment = 500;
            this.nudTradeInValue.Value = 0;
            this.nudTradeInValue.Enabled = false;


            // Set the padding for the ErrorProvider icons
            errorProvider.SetIconPadding(this.nudTradeInValue, 3);



            // Populate the vehicle ComboBox with a minimum of 10 unique vehicles
            cboVehicle.Items.Add(new Vehicle(2019, "Toyota", "Corolla", PaintColor.Sienna, 20000m));
            cboVehicle.Items.Add(new Vehicle(2020, "BMW", "X5", PaintColor.Aquamarine, 30000m));
            cboVehicle.Items.Add(new Vehicle(2021, "Subaru", "Forester", PaintColor.Turquoise, 25000m));
            cboVehicle.Items.Add(new Vehicle(2018, "Ford", "Mustang", PaintColor.Sienna, 28000m));
            cboVehicle.Items.Add(new Vehicle(2019, "Nissan", "Rogue", PaintColor.Azure, 22000m));
            cboVehicle.Items.Add(new Vehicle(2020, "Honda", "Civic", PaintColor.Black, 21000m));
            cboVehicle.Items.Add(new Vehicle(2021, "Chevrolet", "Camaro", PaintColor.Pink, 26000m));
            cboVehicle.Items.Add(new Vehicle(2018, "Hyundai", "Elantra", PaintColor.HotPink, 23000m));
            cboVehicle.Items.Add(new Vehicle(2019, "Volkswagen", "Golf", PaintColor.Aquamarine, 24000m));
            cboVehicle.Items.Add(new Vehicle(2020, "Mercedes-Benz", "E-Class", PaintColor.Turquoise, 32000m));


            // Set the selected index to -1 so no vehicle is selected initially
            cboVehicle.SelectedIndex = -1;

            // Set the focus to the ComboBox
            cboVehicle.Focus();



            // Disable the menu items
            mnuAddOption.Enabled = false;
            mnuRemoveOption.Enabled = false;
            mnuFinancing.Enabled = false;


            // Disable the buttons
            btnAddOption.Enabled = false;
            btnRemoveOption.Enabled = false;


            Restart();


            // Event subscription
            cboVehicle.SelectedIndexChanged += CboVehicle_SelectedIndexChanged;
            mnuNew.Click += MnuNew_Click;
            mnuExit.Click += MnuExit_Click;
            mnuAddOption.Click += MnuAddOption_Click;
            mnuRemoveOption.Click += MnuRemoveOption_Click;
            mnuFinancing.Click += MnuFinancing_Click;
            mnuAbout.Click += MnuAbout_Click;
            nudTradeInValue.Click += NudTradeInValue_Click;
            btnAddOption.Click += BtnAddOption_Click;
            btnRemoveOption.Click += BtnRemoveOption_Click;

        }


        /// <summary>
        /// Handles the Click event of the BtnRemoveOption control.
        /// </summary>
        private void BtnRemoveOption_Click(object sender, EventArgs e)
        {
            if (lstVehicleOptions.SelectedItems != null)
            {
                VehicleOption selectedOption = (VehicleOption)lstVehicleOptions.SelectedItem;

                this.Quote.RemoveOption(selectedOption);

                lstVehicleOptions.Items.Remove(selectedOption);

                UpdateTextBoxControls();

            }
        }

        /// <summary>
        /// Handles the Click event of the BtnAddOption control.
        /// </summary>
        private void BtnAddOption_Click(object sender, EventArgs e)
        {
            AddOptionForm addOptionForm = new AddOptionForm();

            DialogResult result = addOptionForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                VehicleOption createdOption = addOptionForm.RetrieveCreatedOption();
                this.Quote.AddOption(createdOption);
                lstVehicleOptions.Items.Add(createdOption);

                UpdateTextBoxControls();
            };
            cboVehicle.Focus();
        }

        /// <summary>
        /// Handles the Click event of the NudTradeInValue control.
        /// </summary>
        private void NudTradeInValue_Click(object sender, EventArgs e)
        {
            if (this.Quote != null)
            {
                this.Quote.TradeInValue = decimal.Parse(nudTradeInValue.Value.ToString());
            }


            UpdateTextBoxControls();
    
        }

        /// <summary>
        /// Handles the Click event of the MnuAbout control.
        /// </summary>
        private void MnuAbout_Click(object sender, EventArgs e)
        {
            // Create an instance of the AboutForm
            AboutForm aboutForm = new AboutForm();

            // Show the AboutForm as a modal window
            aboutForm.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the MnuFinancing control.
        /// </summary>
        private void MnuFinancing_Click(object sender, EventArgs e)
        {
            // Check if a quote exists
            if (Quote != null)
            {
                // Create an instance of the FinancingForm
                FinancingForm financingForm = new FinancingForm(Quote);

                // Show the FinancingForm as a modal window
                financingForm.ShowDialog();
            }
        }

        /// <summary>
        /// Handles the Click event of the MnuRemoveOption control.
        /// </summary>
        private void MnuRemoveOption_Click(object sender, EventArgs e)
        {
            if (lstVehicleOptions.SelectedItems != null)
            {
                VehicleOption selectedOption = (VehicleOption)lstVehicleOptions.SelectedItem;

                this.Quote.RemoveOption(selectedOption);

                lstVehicleOptions.Items.Remove(selectedOption);

                UpdateTextBoxControls();


            }
        }

        /// <summary>
        /// Handles the Click event of the MnuAddOption control.
        /// </summary>
        private void MnuAddOption_Click(object sender, EventArgs e)
        {
            AddOptionForm addOptionForm = new AddOptionForm();

            DialogResult result = addOptionForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                VehicleOption createdOption = addOptionForm.RetrieveCreatedOption();
                this.Quote.AddOption(createdOption);
                lstVehicleOptions.Items.Add(createdOption);

                UpdateTextBoxControls();
            }

        }

        /// <summary>
        /// Handles the Click event of the MnuExit control.
        /// </summary>
        private void MnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /// <summary>
        /// Handles the SelectedIndexChanged event of the CboVehicle control.
        /// </summary>
        private void CboVehicle_SelectedIndexChanged(object sender, EventArgs e)
        {

            // Get the selected vehicle from the ComboBox
            Vehicle selectedVehicle = (Vehicle)cboVehicle.SelectedItem;


            // Check if a vehicle is selected
            if (selectedVehicle != null)
            {


                // Enable the disabled Menu Items, Buttons, and NumericUpDown
                mnuAddOption.Enabled = true;
                mnuRemoveOption.Enabled = true;
                btnAddOption.Enabled = true;
                btnRemoveOption.Enabled = true;
                nudTradeInValue.Enabled = true;
                mnuFinancing.Enabled = true;

                // If a quote is not created, create a new quote. If a quote is already created, update the state.
                if (this.Quote == null)
                {
                    this.Quote = new VehicleQuote(TaxRate, selectedVehicle);
                }
                else
                {
                    this.Quote.Vehicle = selectedVehicle;
                    this.Quote.TaxRate = TaxRate;
                }

                // Update the maximum trade-in value to match the sale price of the selected vehicle
                nudTradeInValue.Maximum = selectedVehicle.SalePrice;

                // Update the TextBox controls on the form to reflect the state of the quote
                UpdateTextBoxControls();
            }

            else
            {
                Restart();
            }


        }

        /// <summary>
        /// Handles the Click event of the MnuNew control.
        /// </summary>
        private void MnuNew_Click(object sender, EventArgs e)
        {
            // Check if a VehicleQuote is currently created
            if (this.Quote != null)
            {

                // Show a message box asking the user if they want to reset the form
                DialogResult result =
                    MessageBox.Show("The current quote will be lost. Continue?",
                                    "New Quote",
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Warning,
                                    MessageBoxDefaultButton.Button2);

                if (result == DialogResult.Yes)
                {

                    Restart();

                }

            }

        }

        /// <summary>
        /// Refactored code that resets the initial state of the form
        /// </summary>
        private void Restart()
        {
            cboVehicle.SelectedIndex = -1;
            lstVehicleOptions.Items.Clear();
            nudTradeInValue.Value = 0;

            txtAmountDue.Text = "";
            txtSalePrice.Text = "";
            txtSubtotal.Text = "";
            txtTax.Text = "";
            txtTotal.Text = "";
            txtTotalOptions.Text = "";
            errorProvider.Clear();

            // Disable the Menu Items, Buttons, and NumericUpDown
            mnuAddOption.Enabled = false;
            mnuRemoveOption.Enabled = false;
            btnAddOption.Enabled = false;
            btnRemoveOption.Enabled = false;
            nudTradeInValue.Enabled = false;
            mnuFinancing.Enabled = false;




            this.Quote = null;

        }

        /// <summary>
        /// Updates the TextBox controls on the form.
        /// </summary>
        private void UpdateTextBoxControls()
        {
            if (this.Quote != null)
            { 
            txtSubtotal.Text = this.Quote.GetSubtotal().ToString("C");
            txtTotal.Text = this.Quote.CalculateTotalQuote().ToString("C");
            txtAmountDue.Text = this.Quote.GetAmountDue().ToString("C");
            nudTradeInValue.Text = this.Quote.TradeInValue.ToString("C");
            txtSalePrice.Text = this.Quote.SalePrice.ToString("C");
            txtTotalOptions.Text = this.Quote.GetOptionsTotal().ToString("C");
            txtTax.Text = this.Quote.CalculateSalesTax().ToString("C");
            }
        }
    }
}


