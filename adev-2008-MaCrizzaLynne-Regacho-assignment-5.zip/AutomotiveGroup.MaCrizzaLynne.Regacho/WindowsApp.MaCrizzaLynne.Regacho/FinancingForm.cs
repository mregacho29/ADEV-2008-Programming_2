﻿using ACE.BIT.ADEV.Finance;
using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsApp.MaCrizzaLynne.Regacho
{
    internal class FinancingForm : ACE.BIT.ADEV.Forms.FinancingForm
    {
        /// <summary>
        /// Vehicle quote for the financing form.
        /// </summary>
        private VehicleQuote vehicleQuote;

        /// <summary>
        /// Initializes a new instance of the FinancingForm class.
        /// </summary>
        /// <param name="quote">The vehicle quote for the financing form.</param>
        public FinancingForm(VehicleQuote quote)
        {
            vehicleQuote = quote;

            // Center the form to the parent form
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;

            // Set the quote price label to the amount due of the vehicle quote, formatted as currency
            lblQuotedPrice.Text = vehicleQuote.GetAmountDue().ToString("C");

            // Initialize the loan term ComboBox with the items 3, 4, 5, 6, 7
            cboLoanTerm.Items.AddRange(new object[] { 3, 4, 5, 6, 7 });

            // Set the selected item to 5
            cboLoanTerm.SelectedItem = 5;

            // Initialize the annual interest rate NumericUpDown
            nudAnnualInterestRate.Minimum = 0;
            nudAnnualInterestRate.Maximum = 25;
            nudAnnualInterestRate.Increment = 0.25M;
            nudAnnualInterestRate.DecimalPlaces = 2;
            nudAnnualInterestRate.Value = 3.00M;

            UpdateMonthlyPayment();

            // Event Handler
            cboLoanTerm.SelectedIndexChanged += CboLoanTerm_SelectedIndexChanged;
            nudAnnualInterestRate.ValueChanged += NudAnnualInterestRate_ValueChanged;

        }

        /// <summary>
        /// Handles the ValueChanged event of the nudAnnualInterestRate control.
        /// </summary>
        private void NudAnnualInterestRate_ValueChanged(object sender, EventArgs e)
        {
            UpdateMonthlyPayment();
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the cboLoanTerm control.
        /// </summary>
        private void CboLoanTerm_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateMonthlyPayment();
        }

        /// <summary>
        /// Updates the monthly payment based on the selected loan term and annual interest rate.
        /// </summary>
        private void UpdateMonthlyPayment()
        {

            if (cboLoanTerm.SelectedItem != null && nudAnnualInterestRate.Value >0)
            {

                // Calculate the monthly payment
                decimal principal = (decimal)vehicleQuote.GetAmountDue();
                decimal annualInterestRate = nudAnnualInterestRate.Value / 100;
                int termInYears = Convert.ToInt32(cboLoanTerm.SelectedItem);

                // Convert annual interest rate to monthly rate and years to months
                decimal monthlyInterestRate = annualInterestRate / 12m;
                int termInMonths = termInYears * 12;

                decimal monthlyPaymentValue = Financial.GetPayment(monthlyInterestRate, termInMonths, principal);


                txtMonthlyPayment.Text = monthlyPaymentValue.ToString("C");

            }
        }
    }
}
