﻿
using System;
using System.Collections;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-01-17
 */

namespace ConsoleApp.MaCrizzaLynne.Regacho
{
    internal class Program
    {

        static void Main(string[] args)
        {
            VehicleQuote quote1;


            Vehicle vehicle1 = new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 20000m);
            quote1 = new VehicleQuote(0.05m, vehicle1, 0m);


            Console.WriteLine("SalePrice: " + quote1.salePrice.ToString("C"));
            Console.WriteLine("TaxRate: " + quote1.taxRate);


            Console.WriteLine(quote1.ToString());


            VehicleQuote quote2;
            Vehicle vehicle2 = new Vehicle(2012, "Honda", "Civic", PaintColor.Aquamarine, 22000m);
            quote2 = new VehicleQuote(0.07m, vehicle2, 0m);


            quote2.salePrice = 14000m;
            quote2.taxRate = 0.049m;


            List<Vehicle> vehicles;


            vehicles = new List<Vehicle>();


            vehicles.Add(new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 20000m));
            vehicles.Add(new Vehicle(2012, "Honda", "Civic", PaintColor.Aquamarine, 22000m));
            vehicles.Add(new Vehicle(2015, "Ford", "Focus", PaintColor.Black, 24000m));


            Console.WriteLine("Number of vehicles: " + vehicles.Count);


            foreach (Vehicle CurrentVehicle in vehicles)
            {
                Console.WriteLine(CurrentVehicle.ToString());

            }


            ///ASSIGNMENT 02
            // 1. Declare a variable that can reference a Vehicle object.
            Vehicle vehicle;

            // 2. Define the variable from the previous step with a new instance of Vehicle.
            //    The sale price is set here.
            vehicle = new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 33000m);

            // 3. Declare a variable that can reference a VehicleQuote instance.
            VehicleQuote vehicleQuote;

            // 4. Define the variable from the previous step with a new instance of VehicleQuote.
            //    Specify an argument for tax rate, vehicle and trade-in value.
            //    The sale price is obtained from the Vehicle object.
            vehicleQuote = new VehicleQuote(0.0199m, vehicle, 3000m);


            // 5. Define a variable to a new instance of the VehicleOption class.
            VehicleOption vehicleOption = new VehicleOption("Custom Headlight", 500m, 2);

            // 6. Add the VehicleOption created in the previous statement to the options of the
            //    VehicleQuote instance.

            vehicleQuote.AddOption(vehicleOption);

            // 7. Add two more VehicleOption objects to the VehicleQuote instance. Only use two statements
            //    to accomplish this step.

            vehicleQuote.AddOption(new VehicleOption("Decal", 100m, 1));
            vehicleQuote.AddOption(new VehicleOption("Bluetooth Stereo", 900m, 1));

            // 8. Print the quote details to the console.
            //    This step requires defining a sub-procedure method (see below).

            PrintQuoteDetails(vehicleQuote);


            // 9. Remove the first VehicleOption added to the VehicleQuote.
            vehicleQuote.RemoveOption(vehicleOption);

            // 10. Print the number of VehicleOption objects currently in the quote. Ensure you are
            //     obtaining this information using the VehicleQuote object reference.
            Console.WriteLine("Number of options: " + vehicleQuote.GetOptions().Count);

            Console.ReadKey();


        }

        /// <summary>
        /// Prints the details of a VehicleQuote to the console. The output format is as follows:
        /// Vehicle sale price: {price (currency)}
        /// Options:
        ///     {option-description} x {quantity} @ {option-unit-price (currency)}
        /// Subtotal: {subtotal (currency)}
        /// Sales tax: {sales-tax (number)}
        /// Total: {total (currency)}
        /// Trade-in value: {trade-in-value (negative, number)}
        /// Amount due: {amount-due (currency)}
        /// Note: The listing of the options is indented with a tab.
        /// </summary>
        /// <param name="quote">The VehicleQuote details that are to be printed.</param>
        static void PrintQuoteDetails(VehicleQuote quote)
        {
            Console.WriteLine("Vehicle sale price: {0:C}", quote.Vehicle.salePrice);
            Console.WriteLine("Options:");
            foreach (var option in quote.GetOptions())
            {
                Console.WriteLine("\t{0} x {1} @ {2:C}", option.description, option.quantity, option.unitPrice);
            }
            Console.WriteLine("Subtotal: {0:C}", quote.GetSubtotal());
            Console.WriteLine("Sales tax: {0:C}", quote.CalculateSalesTax());
            Console.WriteLine("Total: {0:C}", quote.CalculateTotalQuote());
            Console.WriteLine("Trade-in value: -{0:C}", quote.TradeInValue);
            Console.WriteLine("Amount due: {0:C}", quote.GetAmountDue());
        }

    }
}