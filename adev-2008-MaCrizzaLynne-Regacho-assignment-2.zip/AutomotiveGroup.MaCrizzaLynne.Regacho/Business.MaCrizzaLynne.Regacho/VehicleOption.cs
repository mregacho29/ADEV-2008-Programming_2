﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-02-02
 * Updated: 2024-02-03
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    ///  The VehicleOption class represents an option that can be added to a vehicle.
    /// </summary>
    public class VehicleOption
    {
        /// <summary>
        /// Description, Price per unit, Number of the option ordered of the vehicle option. 
        /// </summary>
        private string Description;
        private decimal UnitPrice;
        private int Quantity;

        /// <summary>
        /// Public properties to get the values of the description, unit price, and quantity.
        /// These attributes can be retrieved, but not modified.
        /// </summary>
        public string description
        {
            get => this.Description;
        }

        public decimal unitPrice
        {
            get => this.UnitPrice;
        }

        public int quantity
        {
            get => this.Quantity;
        }

        /// <summary>
        /// Initializes a new instance of the VehicleOption class with the specified description, unit price, and quantity.
        /// </summary>
        /// <param name="Description">The description of the vehicle option. It must contain at least one non-whitespace character.</param>
        /// <param name="UnitPrice">The price per unit of the vehicle option. It must be 0 or greater.</param>
        /// <param name="Quantity">The number of the option ordered. It must be 0 or greater.</param>
        /// <exception cref="ArgumentException">Thrown when the description is empty or contains only whitespace.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the unit price or quantity is less than 0.</exception>
        public VehicleOption(string Description, decimal UnitPrice, int Quantity)
        {
            if (Description.Trim().Equals(string.Empty))
            {
                throw new ArgumentException("The description must contain at least one non-whitespace character.", nameof(Description));
            }

            if (UnitPrice < 0) 
            {
                throw new ArgumentOutOfRangeException(nameof(UnitPrice), "The unit price must be 0 or greater.");
            }

            if (Quantity < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(Quantity), "The quantity must be 0 or greater.");
            }


            this.Description = Description;
            this.UnitPrice = UnitPrice;
            this.Quantity = Quantity;
        }

        /// <summary>
        /// Returns a string that represents the current VehicleOption object.
        /// </summary>
        /// <returns>
        /// A string that represents the current VehicleOption object in the format: "{Description} x {Quantity} @ {UnitPrice formatted as currency}".
        /// For example: "Custom Headlight x 2 @ $500.00".
        /// </returns>
        public override string ToString()
        {
            return String.Format("{0} x {1} @ {2:C}", Description, Quantity, UnitPrice);
        }
    }
}
