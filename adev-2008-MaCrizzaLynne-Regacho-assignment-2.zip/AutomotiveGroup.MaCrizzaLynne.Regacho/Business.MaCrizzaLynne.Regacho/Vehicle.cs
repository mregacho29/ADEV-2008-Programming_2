﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-02-02
 * Updated: 2024-02-02
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// This represents a vehicle
    /// </summary>
    public class Vehicle
    {
        private int Year;
        private string Model;
        private string Manufacturer;
        private PaintColor Color;
        private decimal SalePrice;

        /// <summary>
        /// Gets the year vehicle was manufactured.
        /// </summary>
        public int year
        {
            get => this.Year;
        }

        /// <summary>
        /// Gets the model of the vehicle.
        /// </summary>
        public string model
        {
            get => this.Model;
        }

        /// <summary>
        /// Gets the manufacturer of the vehicle.
        /// </summary>
        public string manufacturer
        {
            get => this.Manufacturer;
        }

        /// <summary>
        /// Gets the color of the vehicle.
        /// </summary>
        public PaintColor color
        {
            get => this.Color;
        }

        /// <summary>
        /// Gets the sale price of the vehicle.
        /// </summary>
        public decimal salePrice
        {
            get => this.SalePrice;
        }

        /// <summary>
        /// Initializes a new instance of the Vehicle class.
        /// </summary>
        /// <param name="Year">The year the vehicle was manufactured.</param>
        /// <param name="Model">The model of the vehicle.</param>
        /// <param name="Manufacturer">The manufacturer of the vehicle.</param>
        /// <param name="Color">The color of the vehicle.</param>
        /// <param name="SalePrice">The sale price of the vehicle.</param>

        public Vehicle(int Year, string Model, string Manufacturer, 
            PaintColor Color, decimal SalePrice)
        {
            /// Check if the year is less than 1950
            if (Year < 1950)
            {
                throw new ArgumentOutOfRangeException(nameof(Year), 
                    string.Format("The {0} must be in the range of 1950 to {1}.",
                    nameof(Year), DateTime.Now.Year + 1));
            }

            // Check if the year is greater than the current year plus one
            if (Year > DateTime.Now.Year + 1)
            {
                throw new ArgumentOutOfRangeException(nameof(Year),
                    string.Format("The {0} must be in the range of 1950 to {1}.",
                    nameof(Year), DateTime.Now.Year + 1));
            }

            // Check if the manufacturer is null or whitespace
            if (string.IsNullOrWhiteSpace(Manufacturer))
            {
                throw new ArgumentException(
                    string.Format("The {0} must contain non-whitespace characters.", 
                    nameof(Manufacturer)), nameof(Manufacturer));
            }

            // Check if the model is null or whitespace
            if (string.IsNullOrWhiteSpace(Model))
            {
                throw new ArgumentException(
                    string.Format("The {0} must contain non-whitespace characters.", 
                    nameof(Model)), nameof(Model));
            }

            // Check if the sale price is less than 0
            if (SalePrice < 0)
            {
                throw new ArgumentOutOfRangeException("Error: SalePrice must be 0 or greater.");
            }


            this.Year = Year;
            this.Model = Model;
            this.Manufacturer = Manufacturer;
            this.Color = Color;
            this.SalePrice = SalePrice;
        }


        /// <summary>
        /// Returns a string that represents the current Vehicle object.
        /// </summary>
        /// <returns>A string in the format "{Year}, {Manufacturer}, {Model}, {Color}".</returns>
        public override string ToString()
        {
            return String.Format("{0}, {1}, {2}, {3}", Year, Manufacturer,
                Model, Color);
        }
    }
}

