﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-02-02
 * Updated: 2024-02-02
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// Enumeration for PaintColors
    /// </summary>
    public enum PaintColor
    {
        HotPink,
        Aquamarine,
        Turquoise,
        Sienna,
        Azure,
        Black,
        Pink
    }
}
