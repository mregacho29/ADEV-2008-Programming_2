﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// The VehicleQuote class inherits from the Quote class
    /// </summary>
    public class VehicleQuote : Quote
    {
        /// <summary>
        /// Private Attributes
        /// </summary>
        private decimal tradeInValue;
        private List<VehicleOption> options;
        private Vehicle vehicle;

        /// <summary>
        /// Public property for trade-in value with validation
        /// </summary>
        public decimal TradeInValue
        {
            get => this.tradeInValue;
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), "The value must be 0 or greater.");
                }
                this.tradeInValue = value;
            }
        }

        /// <summary>
        /// Public property for vehicle with validation.
        /// </summary>
        public Vehicle Vehicle
        {
            get => this.vehicle;
            set
            {
                if (value == null) 
                {
                    throw new ArgumentNullException(nameof(value), "The value must be a reference to a Vehicle.");
                }
                this.vehicle = value;
                this.salePrice = vehicle.salePrice;
            }
        }

        /// <summary>
        /// Initializes a new instance of the VehicleQuote class with a specified tax rate and vehicle.
        /// The trade-in value is set to zero and the options attribute is initialized to an empty List.
        /// </summary>
        /// <param name="taxRate">The tax rate for the vehicle quote.</param>
        /// <param name="vehicle">The vehicle for which the quote is being prepared.</param>
        /// <exception cref="NullReferenceException">Thrown when the vehicle argument is null.</exception>
        public VehicleQuote(decimal taxRate, Vehicle vehicle) : base(vehicle.salePrice, taxRate)
        {
            if (vehicle == null)
            {
                throw new NullReferenceException("The vehicle argument must not be null.");
            }

            this.tradeInValue = 0;
            this.vehicle = vehicle;
            this.options = new List<VehicleOption>();
        }


        /// <summary>
        /// Initializes a new instance of the VehicleQuote class with a specified tax rate, vehicle, and trade-in value.
        /// The options attribute is initialized to an empty List.
        /// </summary>
        /// <param name="taxRate">The tax rate for the vehicle quote.</param>
        /// <param name="vehicle">The vehicle for which the quote is being prepared.</param>
        /// <param name="tradeInValue">The trade-in value for the vehicle, must be 0 or greater.</param>
        /// <exception cref="NullReferenceException">Thrown when the vehicle argument is null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the trade-in value is less than 0.</exception>
        public VehicleQuote(decimal taxRate, Vehicle vehicle, decimal tradeInValue) : base(vehicle.salePrice, taxRate)
        {
            if (vehicle == null)
            {
                throw new NullReferenceException("The vehicle argument must not be null.");
            }

            if (tradeInValue < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(tradeInValue), "The trade-in value must be 0 or greater.");
            }

            this.tradeInValue = tradeInValue; 
            this.vehicle = vehicle;
            this.options = new List<VehicleOption>();  
        }

        /// <summary>
        /// Adds a specified VehicleOption to the options of the VehicleQuote.
        /// </summary>
        /// <param name="option">The VehicleOption to be added to the VehicleQuote.</param>
        /// <exception cref="ArgumentNullException">Thrown when the option argument is null.</exception>
        public void AddOption(VehicleOption option)
        {
            if (option == null)
            {
                throw new ArgumentNullException(nameof(option), "The option must reference an object.");
            }
            this.options.Add(option);
        }

        /// <summary>
        /// Removes a specified VehicleOption from the options of the VehicleQuote.
        /// </summary>
        /// <param name="option">The VehicleOption to be removed from the VehicleQuote.</param>
        public void RemoveOption(VehicleOption option) 
        { 
            this.options.Remove(option);
        }

        /// <summary>
        /// Returns a copy of the options of the VehicleQuote.
        /// The method returns an entirely new List containing the same VehicleOption objects as the internal options state.
        /// </summary>
        /// <returns>A new List of VehicleOption objects that are currently in the VehicleQuote.</returns>
        public List<VehicleOption> GetOptions()
        {
            return new List<VehicleOption>(this.options);
        }

        /// <summary>
        /// Returns the sum of the VehicleQuote options.
        /// </summary>
        /// <returns>The total price of all the VehicleOption objects currently in the VehicleQuote.</returns>
        public decimal GetOptionsTotal()
        {
            return this.options.Sum(option => option.unitPrice * option.quantity);
        }

        /// <summary>
        /// Returns the subtotal of the VehicleQuote.
        /// The subtotal is the sum of the sale price and the total price of the options added to the VehicleQuote.
        /// </summary>
        /// <returns>The subtotal of the VehicleQuote.</returns>
        public decimal GetSubtotal()
        {
            return this.salePrice + GetOptionsTotal();
        }

        /// <summary>
        /// Returns the VehicleQuote sale tax.
        /// The sales tax is based on a percentage of the subtotal. 
        /// </summary>
        /// <returns>The calculated sales tax for the VehicleQuote.</returns>
        public override decimal CalculateSalesTax()
        {
            return this.GetSubtotal() * this.taxRate;
        }

        /// <summary>
        /// /// Calculates and returns the total of the VehicleQuote.
        /// The total is the sum of the subtotal and sales tax, rounded to two decimal places.
        /// </summary>
        /// <returns>The total of the VehicleQuote, rounded to two decimal places.</returns>
        public override decimal CalculateTotalQuote()
        {
            decimal total = this.GetSubtotal() + this.CalculateSalesTax();
            return Math.Round(total, 2);
        }

        /// <summary>
        /// Calculates and returns the amount due for the vehicle being purchased.
        /// The amount due is the VehicleQuote total minus the trade-in value.
        /// </summary>
        /// <returns>The amount due for the vehicle being purchased.</returns>
        public decimal GetAmountDue()
        {
            return CalculateTotalQuote() - this.tradeInValue;
        }

        /// <summary>
        /// Returns a string that represents the current VehicleQuote.
        /// The string is in the format: "VehicleQuote: {amount-due-formatted-as-currency}"
        /// </summary>
        /// <returns>A string that represents the current VehicleQuote.</returns>
        public override string ToString()
        {
            return String.Format("VehicleQuote: {0:C}", this.GetAmountDue());
        }

    }
}