﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-01-17
 */

namespace ConsoleApp.MaCrizzaLynne.Regacho
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1. Declare a variable of Quote type.
            Quote quote1;

            // 2. Define the variable above to a new Quote instance with a sale price
            //    and tax rate of your choosing.
            quote1 = new Quote(5000m, 0.05m);

            // 3. Print the state of the Quote object using accessor methods. 
            //    Format of the output is: 
            //    field: value
            Console.WriteLine("SalePrice: " + quote1.GetSalePrice().ToString("C"));
            Console.WriteLine("TaxRate: " + quote1.GetTaxRate());

           

            // 4. Print the Quote instance created in a previous step.
            Console.WriteLine(quote1.ToString());
            
            
            // 5. Declare and define a new Quote object with the default state.
            Quote quote2;
            
            quote2 = new Quote();

            // 6. Update the state of the second Quote object with a sale price 
            //    between $10,000 - $15,000 and a tax rate between 4.01% and 4.99% 
            //    (inclusive).
            quote2.SetSalePrice(14000m);
            quote2.SetTaxRate(0.049m);

            // 7. Declare a variable of List type that can store Vehicle objects.
            List<Vehicle> vehicles;

           

            // 8. Define the variable from the previous step to an empty List object.
            vehicles = new List<Vehicle>();


            // 9. Populate the List with 3 Vehicle objects. Each Vehicle object must 
            //    have unique state.
            vehicles.Add(new Vehicle(2010, "Toyota", "Corolla", PaintColor.Sienna, 20000m));
            vehicles.Add(new Vehicle(2012, "Honda", "Civic", PaintColor.Aquamarine, 22000m));
            vehicles.Add(new Vehicle(2015, "Ford", "Focus", PaintColor.Black, 24000m));

            // 10. Print out the number of objects in the List, using the List object
            //     reference.
            Console.WriteLine("Number of vehicles: " + vehicles.Count);


            // 11. Print out the Vehicle objects from the List.
            foreach (Vehicle CurrentVehicle in vehicles)
            {
                Console.WriteLine(CurrentVehicle.ToString());

                /* Print the Sales Price and its Total Quote for each vehicle
                Console.WriteLine("Sale price: " + CurrentVehicle.GetSalePrice().ToString("C"));
                
                // Create a new Quote object with the sale price of the vehicle and a tax rate of 0.049
                Quote quoteForVehicle = new Quote(CurrentVehicle.GetSalePrice(), 0.049m);

                // Print the quote for the vehicle
                Console.WriteLine(quoteForVehicle.ToString());
                */

            }


            Console.ReadKey();
        }
    }
}



