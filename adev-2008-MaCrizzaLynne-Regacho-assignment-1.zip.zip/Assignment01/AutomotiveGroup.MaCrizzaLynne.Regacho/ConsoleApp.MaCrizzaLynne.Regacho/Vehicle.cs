﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-01-17
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// This represents a vehicle
    /// </summary>
    public class Vehicle
    {
        private int Year;
        private string Model;
        private string Manufacturer;
        private PaintColor Color;
        private decimal SalePrice;

        /// <summary>
        /// Initializes a new instance of the Vehicle class.
        /// </summary>
        /// <param name="Year">The year the vehicle was manufactured.</param>
        /// <param name="Model">The model of the vehicle.</param>
        /// <param name="Manufacturer">The manufacturer of the vehicle.</param>
        /// <param name="Color">The color of the vehicle.</param>
        /// <param name="SalePrice">The sale price of the vehicle.</param>

        public Vehicle(int Year, string Model, string Manufacturer, 
            PaintColor Color, decimal SalePrice)
        {
            this.Year = Year;
            this.Model = Model;
            this.Manufacturer = Manufacturer;
            this.Color = Color;
            this.SalePrice = SalePrice;
        }


        /// <summary>
        /// Get the year the vehicle was manufactured
        /// </summary>
        /// <returns>the year</returns>
        public int GetYear()
        {
            return Year;
        }

  
        /// <summary>
        /// Get the model of the vehicle
        /// </summary>
        /// <returns>the model</returns>
        public string GetModel() 
        { 
            return Model;
        }


        /// <summary>
        /// Gets the manufacturer of the vehicle
        /// </summary>
        /// <returns>the manufacturer</returns>
        public string GetManufacturer() 
        {
            return Manufacturer;
        }



        /// <summary>
        /// Gets the color of the vehicle
        /// </summary>
        /// <returns>the color</returns>
        public PaintColor GetColor()
        {
            return Color;

        }


        /// <summary>
        /// Gets the sale price of the vehicle
        /// </summary>
        /// <returns>the sale price</returns>
        public decimal GetSalePrice() 
        {
            return SalePrice;
        }



        /// <summary>
        /// Returns a string that represents the current Vehicle object.
        /// </summary>
        /// <returns>A string in the format "{Year}, {Manufacturer}, {Model}, {Color}".</returns>
        public override string ToString()
        {
            return String.Format("{0}, {1}, {2}, {3}", GetYear(), GetManufacturer(),
                GetModel(), GetColor());
        }
    }
}

