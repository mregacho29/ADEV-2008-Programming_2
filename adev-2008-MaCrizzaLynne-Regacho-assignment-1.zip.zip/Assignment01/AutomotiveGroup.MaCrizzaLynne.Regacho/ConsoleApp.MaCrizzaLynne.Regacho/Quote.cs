﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-01-17
 */

namespace Business.MaCrizzaLynne.Regacho
{
    public class Quote
    {
        private decimal SalePrice;
        private decimal TaxRate;

        /// <summary>
        /// Constructor with arguments
        /// </summary>
        /// <param name="salePrice"></param>
        /// <param name="taxRate"></param>
        public Quote(decimal salePrice, decimal taxRate)
        {
            this.SalePrice = salePrice;
            this.TaxRate = taxRate;
        }

        /// <summary>
        /// Constructor without arguments
        /// </summary>
        public Quote()
        {
            this.SalePrice = 0m;
            this.TaxRate = 0m;
        }


        /// <summary>
        /// Accessor and mutator methods
        /// </summary>
        public decimal GetSalePrice()
        {
            return SalePrice;
        }

        public void SetSalePrice(decimal salePrice) 
        {
            this.SalePrice = salePrice;
        }



        public decimal GetTaxRate()
        {
            return TaxRate;
        }

        public void SetTaxRate(decimal taxRate) 
        {
            this.TaxRate = taxRate;
        }



        /// <summary>
        /// Method to calculate sales tax
        /// </summary>
        public decimal CalculateSalesTax()
        {
            return this.SalePrice * this.TaxRate;
        }

        /// <summary>
        /// Method to calculate total quote
        /// </summary>
        public decimal CalculateTotalQuote()
        {
            return this.SalePrice + CalculateSalesTax();
        }

        /// <summary>
        /// A string representation of a Quote object
        /// </summary>
        /// <returns>>A string in the format "Quote: {total-formatted-as-currency}"</returns>
        public override string ToString()
        {
            return String.Format("Quote: {0:c}", CalculateTotalQuote());
        }
    }
}
