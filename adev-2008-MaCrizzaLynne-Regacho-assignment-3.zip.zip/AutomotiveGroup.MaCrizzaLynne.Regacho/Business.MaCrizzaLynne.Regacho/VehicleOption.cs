﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-02-02
 * Updated: 2024-02-03
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    ///  The VehicleOption class represents an option that can be added to a vehicle.
    /// </summary>
    public class VehicleOption
    {
        /// <summary>
        /// Description, Price per unit, Number of the option ordered of the vehicle option. 
        /// </summary>
        private string description;
        private decimal unitPrice;
        private int quantity;

        /// <summary>
        /// Public properties to get the values of the description, unit price, and quantity.
        /// These attributes can be retrieved, but not modified.
        /// </summary>
        public string Description
        {
            get => this.description;
        }

        public decimal UnitPrice
        {
            get => this.unitPrice;
        }

        public int Quantity
        {
            get => this.quantity;
        }

        /// <summary>
        /// Initializes a new instance of the VehicleOption class with the specified description, unit price, and quantity.
        /// </summary>
        /// <param name="description">The description of the vehicle option. It must contain at least one non-whitespace character.</param>
        /// <param name="unitPrice">The price per unit of the vehicle option. It must be 0 or greater.</param>
        /// <param name="quantity">The number of the option ordered. It must be 0 or greater.</param>
        /// <exception cref="ArgumentException">Thrown when the description is empty or contains only whitespace.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the unit price or quantity is less than 0.</exception>
        public VehicleOption(string description, decimal unitPrice, int quantity)
        {
            if (description.Trim().Equals(string.Empty))
            {
                throw new ArgumentException("The description must contain at least one non-whitespace character.", nameof(description));
            }

            if (unitPrice < 0) 
            {
                throw new ArgumentOutOfRangeException(nameof(unitPrice), "The unit price must be 0 or greater.");
            }

            if (quantity < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(quantity), "The quantity must be 0 or greater.");
            }


            this.description = description;
            this.unitPrice = unitPrice;
            this.quantity = quantity;
        }

        /// <summary>
        /// Returns a string that represents the current VehicleOption object.
        /// </summary>
        /// <returns>
        /// A string that represents the current VehicleOption object in the format: "{Description} x {Quantity} @ {UnitPrice formatted as currency}".
        /// For example: "Custom Headlight x 2 @ $500.00".
        /// </returns>
        public override string ToString()
        {
            return String.Format("{0} x {1} @ {2:C}", description, quantity, unitPrice);
        }
    }
}
