﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;


/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-02-03
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// Abstract class quote
    /// </summary>
    public abstract class Quote
    {
        /// <summary>
        /// Private fields for SalePrice and TaxRate.
        /// </summary>
        private decimal salePrice;
        private decimal taxRate;

        /// <summary>
        // Property for salePrice with validation in setter
        // Can be retrieved and modified
        // Throws an exception if set to a value less than or equal to zero
        /// </summary>
        public decimal SalePrice
        {
            get => this.salePrice;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(SalePrice), "The SalePrice must be greater than 0.");
                }
                this.salePrice = value;
            }
        }


        /// <summary>
        // Property for taxRate
        // Can be retrieved but not modified
        // Throws an exception if set to a value less than zero or greater than one.
        /// </summary>
        public decimal TaxRate
        {
            get => this.taxRate;
            set
            {
                if (value < 0 || value > 1)
                {
                    throw new ArgumentOutOfRangeException(nameof(TaxRate), "The TaxRate must be within the range of 0 to 1 (inclusive).");
                }

                this.taxRate = value;
            }
        }

        /// <summary>
        /// Constructor with arguments for salePrice and taxRate
        /// </summary>
        /// <param name="salePrice">The sale price of the item</param>
        /// <param name="taxRate">The tax rate applied to the sales</param>
        public Quote(decimal salePrice, decimal taxRate)
        {
            this.SalePrice = salePrice;
            this.TaxRate = taxRate;
        }


        /// <summary>
        /// Method to calculate sales tax
        /// Can be overridden in a derived class
        /// </summary>
        public virtual decimal CalculateSalesTax()
        {
            return this.salePrice * this.taxRate;
        }

        /// <summary>
        /// Method to calculate total quote
        /// Can be overridden in a derived class
        /// </summary>
        public virtual decimal CalculateTotalQuote()
        {
            return this.salePrice + CalculateSalesTax();
        }



        //check if I should remove this after refactoring
        /// <summary>
        /// A string representation of a Quote object
        /// </summary>
        /// <returns>>A string in the format "Quote: {total-formatted-as-currency}"</returns>
        public override string ToString()
        {
            return String.Format("Quote: {0:c}", CalculateTotalQuote());
        }
    }
}
