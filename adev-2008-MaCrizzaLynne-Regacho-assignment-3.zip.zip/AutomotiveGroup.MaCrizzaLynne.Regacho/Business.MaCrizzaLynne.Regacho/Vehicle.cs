﻿using Business.MaCrizzaLynne.Regacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-01-17
 * Updated: 2024-02-02
 */

namespace Business.MaCrizzaLynne.Regacho
{
    /// <summary>
    /// This represents a vehicle
    /// </summary>
    public class Vehicle
    {
        private int year;
        private string model;
        private string manufacturer;
        private PaintColor color;
        private decimal salePrice;

        /// <summary>
        /// Gets the year vehicle was manufactured.
        /// </summary>
        public int Year
        {
            get => this.year;
        }

        /// <summary>
        /// Gets the model of the vehicle.
        /// </summary>
        public string Model
        {
            get => this.model;
        }

        /// <summary>
        /// Gets the manufacturer of the vehicle.
        /// </summary>
        public string Manufacturer
        {
            get => this.manufacturer;
        }

        /// <summary>
        /// Gets the color of the vehicle.
        /// </summary>
        public PaintColor Color
        {
            get => this.color;
        }

        /// <summary>
        /// Gets the sale price of the vehicle.
        /// </summary>
        public decimal SalePrice
        {
            get => this.salePrice;
        }

        /// <summary>
        /// Initializes a new instance of the Vehicle class.
        /// </summary>
        /// <param name="year">The year the vehicle was manufactured.</param>
        /// <param name="model">The model of the vehicle.</param>
        /// <param name="manufacturer">The manufacturer of the vehicle.</param>
        /// <param name="color">The color of the vehicle.</param>
        /// <param name="salePrice">The sale price of the vehicle.</param>

        public Vehicle(int year, string model, string manufacturer, 
            PaintColor color, decimal salePrice)
        {
            /// Check if the year is less than 1950
            if (year < 1950)
            {
                throw new ArgumentOutOfRangeException(nameof(year), 
                    string.Format("The {0} must be in the range of 1950 to {1}.",
                    nameof(year), DateTime.Now.Year + 1));
            }

            // Check if the year is greater than the current year plus one
            if (year > DateTime.Now.Year + 1)
            {
                throw new ArgumentOutOfRangeException(nameof(year),
                    string.Format("The {0} must be in the range of 1950 to {1}.",
                    nameof(year), DateTime.Now.Year + 1));
            }

            // Check if the manufacturer is null or whitespace
            if (string.IsNullOrWhiteSpace(manufacturer))
            {
                throw new ArgumentException(
                    string.Format("The {0} must contain non-whitespace characters.", 
                    nameof(manufacturer)), nameof(manufacturer));
            }

            // Check if the model is null or whitespace
            if (string.IsNullOrWhiteSpace(model))
            {
                throw new ArgumentException(
                    string.Format("The {0} must contain non-whitespace characters.", 
                    nameof(model)), nameof(model));
            }

            // Check if the sale price is less than 0
            if (salePrice < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(salePrice), "Error: SalePrice must be 0 or greater.");
            }


            this.year = year;
            this.model = model;
            this.manufacturer = manufacturer;
            this.color = color;
            this.salePrice = salePrice;
        }


        /// <summary>
        /// Returns a string that represents the current Vehicle object.
        /// </summary>
        /// <returns>A string in the format "{Year}, {Manufacturer}, {Model}, {Color}".</returns>
        public override string ToString()
        {
            return String.Format("{0}, {1}, {2}, {3}", year, manufacturer,
                model, color);
        }
    }
}

