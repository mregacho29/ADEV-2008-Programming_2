﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-03-04
 * Updated: 2024-03-05
 */

namespace Test.Business.MaCrizzaLynne.Regacho
{
    #region Naming Convention for Unit Test Methods
    //naming convention for unit test methods:
    //{unit that your testing}_{test scenario}_{expected behaviour}

    //Testing steps
    //AAA Arrange: set up the details of the test
    //Act: invoke the scenario
    //Assert: verify the results 
    #endregion

    [TestClass]
    public class VehicleOptionTest
    {

        #region Constructor Methods
        // Constructor_DescriptionContainsOnlyWhitespace_ThrowsArgumentException
        [TestMethod]
        public void Constructor_DescriptionIsWhitespace_ThrowsException()
        {
            // Arrange
            string description = "   ";
            decimal unitPrice = 500m;
            int quantity = 2;

            // Act & Assert
            ArgumentException exception = Assert.ThrowsException<ArgumentException>(() => new VehicleOption(description, unitPrice, quantity));

            // Assert exception state
            Assert.AreEqual("description", exception.ParamName);
            Assert.AreEqual("The description must contain at least one non-whitespace character.", GetExceptionMessage(exception.Message));
        }



        // Constructor_UnitPriceIsLessThanZero_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_UnitPriceIsLessThanZero_ThrowsException()
        {
            // Arrange
            string description = "Test Description";
            decimal unitPrice = -1m;
            int quantity = 2;

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => new VehicleOption(description, unitPrice, quantity));

            // Assert exception state
            Assert.AreEqual("unitPrice", exception.ParamName);
            Assert.AreEqual("The unit price must be 0 or greater.", GetExceptionMessage(exception.Message));
        }


        // VehicleOption_ConstructorWithNegativeQuantity_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_QuantityIsLessThanZero_ThrowsException()
        {
            // Arrange
            string description = "Test Description";
            decimal unitPrice = 500m;
            int quantity = -1;

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(() => new VehicleOption(description, unitPrice, quantity));

            // Assert exception state
            Assert.AreEqual("quantity", exception.ParamName);
            Assert.AreEqual("The quantity must be 0 or greater.", GetExceptionMessage(exception.Message));
        }


        // VehicleOption_ConstructorWithValidArguments_InitializesAttributes
        [TestMethod]
        public void Constructor_Initialize_VehicleOption()
        {
            // Arrange
            string description = "Test Description";
            decimal unitPrice = 500m;
            int quantity = 2;

            // Act
            VehicleOption vehicleOption = new VehicleOption(description, unitPrice, quantity);

            // Assert
            PrivateObject privateObject = new PrivateObject(vehicleOption);

            Assert.AreEqual(description, privateObject.GetField("description"));
            Assert.AreEqual(unitPrice, privateObject.GetField("unitPrice"));
            Assert.AreEqual(quantity, privateObject.GetField("quantity"));
        }
        #endregion

        #region Method Test

        // VehicleOption_ToString_ReturnsStringRepresentation
        [TestMethod]
        public void ToString_Return_VehicleOptionStringRepresentation()
        {
            // Arrange
            string description = "Test Description";
            decimal unitPrice = 500m;
            int quantity = 2;

            // Act
            VehicleOption vehicleOption = new VehicleOption(description, unitPrice, quantity);
            string vehicleOptionString = vehicleOption.ToString();

            // Assert
            Assert.AreEqual($"{description} x {quantity} @ {unitPrice:C}", vehicleOptionString);
        } 
        #endregion

        #region Helper Methods
        /// <summary>
        /// Helper method to obtain only the message from an Exception object.
        /// </summary>
        /// <param name="exceptionMessage">The Exception's Message state.</param>
        /// <returns>The Exception's message with the parameter omitted.</returns>
        /// <remarks>
        /// The Exception.Message property returns the Exception's message on line 1 and
        /// the parameter name on line 2. This method reads the first line and returns
        /// the message.
        /// </remarks>
        private string GetExceptionMessage(string exceptionMessage)
        {
            return new System.IO.StringReader(exceptionMessage).ReadLine();
        } 
        #endregion
    }
}
