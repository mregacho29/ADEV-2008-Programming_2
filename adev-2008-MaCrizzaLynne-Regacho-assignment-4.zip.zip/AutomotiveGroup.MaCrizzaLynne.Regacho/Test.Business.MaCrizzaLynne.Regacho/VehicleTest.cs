﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Business.MaCrizzaLynne.Regacho;

/*
 * Name: Ma Crizza Lynne Regacho
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2024-03-04
 * Updated: 2024-03-04
 */

namespace Test.Business.MaCrizzaLynne.Regacho
{
    #region Naming Convention for Unit Test Methods

    //naming convention for unit test methods:
    //{unit that your testing}_{test scenario}_{expected behaviour}

    //Testing steps
    //AAA Arrange: set up the details of the test
    //Act: invoke the scenario
    //Assert: verify the results
    #endregion

    [TestClass]
    public class VehicleTest
    {

        #region Constructor Test

        // Vehicle_ConstructorWithYearLessThanMinimum_ThrowsException
        [TestMethod]
        public void Constructor_YearLessThanMinimum_ThrowsException()
        {
            // Arrange
            int year = 1949;
            string model = "Corolla";
            string manufacturer = "Toyota";
            PaintColor color = PaintColor.Sienna;
            decimal salePrice = 20000m;

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(
                () => new Vehicle(year, model, manufacturer, color, salePrice));

            // Assert exception state
            Assert.AreEqual(nameof(year), exception.ParamName);
            Assert.AreEqual($"The {nameof(year)} must be in the range of 1950 to {DateTime.Now.Year + 1}.", GetExceptionMessage(exception.Message));
        }


        //YearArgument_IsGreaterThanNextYear_ThrowsArgumentOutOfRangeException
        [TestMethod]
        public void Constructor_YearGreaterThanNextYear_ThrowsException()
        {
            // Arrange
            int year = DateTime.Now.Year + 2;
            string model = "Corolla";
            string manufacturer = "Toyota";
            PaintColor color = PaintColor.Sienna;
            decimal salePrice = 20000m;

            // Act & Assert
            ArgumentOutOfRangeException exception = Assert.ThrowsException<ArgumentOutOfRangeException>(
                () => new Vehicle(year, model, manufacturer, color, salePrice));

            // Assert exception state
            Assert.AreEqual(nameof(year), exception.ParamName);
            Assert.AreEqual($"The {nameof(year)} must be in the range of 1950 to {DateTime.Now.Year + 1}.", GetExceptionMessage(exception.Message));
        }


        // ManufacturerArgument_ContainsOnlyWhitespace_ThrowsArgumentException
        [TestMethod]
        public void Constructor_ManufacturerOnlyWhitespace_ThrowsException()
        {
            // Arrange
            int year = 2020;
            string model = "Corolla";
            string manufacturer = "   ";
            PaintColor color = PaintColor.Sienna;
            decimal salePrice = 20000m;

            // Act & Assert
            ArgumentException exception = Assert.ThrowsException<ArgumentException>(
                () => new Vehicle(year, model, manufacturer, color, salePrice));

            // Assert exception state
            Assert.AreEqual(nameof(manufacturer), exception.ParamName);
            Assert.AreEqual("The manufacturer must contain non-whitespace characters.", GetExceptionMessage(exception.Message));
        }



        // VehicleConstructor_ModelWhitespace_ThrowsArgumentException
        [TestMethod]
        public void Constructor_ModelOnlyWhitespace_ThrowsException()
        {
            // Arrange:
            int year = 2020;
            string model = "   ";
            string manufacturer = "Toyota";
            PaintColor color = PaintColor.Black;
            decimal salePrice = 20000m;

            // Act & Assert
            ArgumentException exception = Assert.ThrowsException<ArgumentException>(
                () => new Vehicle(year, model, manufacturer, color, salePrice));

            // Assert exception state
            Assert.AreEqual(nameof(model), exception.ParamName);
            Assert.AreEqual("The model must contain non-whitespace characters.", GetExceptionMessage(exception.Message));
        }


        // SalePriceArgument_IsLessThanZero_ThrowsArgumentException
        [TestMethod]
        public void Constructor_SalePriceLessThanZero_ThrowsException()
        {
            // Arrange
            int year = 2020;
            string model = "Corolla";
            string manufacturer = "Toyota";
            PaintColor color = PaintColor.Sienna;
            decimal salePrice = -1m;

            // Act & Assert
            var exception = Assert.ThrowsException<ArgumentOutOfRangeException>(
                () => new Vehicle(year, model, manufacturer, color, salePrice));

            // Assert exception state
            Assert.AreEqual(nameof(salePrice), exception.ParamName);
            Assert.AreEqual("Error: SalePrice must be 0 or greater.", GetExceptionMessage(exception.Message));
        }



        // VehicleConstructor_ValidArguments_AttributesAreInitialized
        [TestMethod]
        public void Constructor_ValidArguments_AttributesAreInitialized()
        {
            // Arrange
            int expectedYear = 2020;
            string expectedModel = "Corolla";
            string expectedManufacturer = "Toyota";
            PaintColor expectedColor = PaintColor.Sienna;
            decimal expectedSalePrice = 20000m;

            // Act
            Vehicle vehicle = new Vehicle(expectedYear, expectedModel, expectedManufacturer, expectedColor, expectedSalePrice);

            // Assert
            PrivateObject privateObject = new PrivateObject(vehicle);

            Assert.AreEqual(expectedYear, privateObject.GetField("year"));
            Assert.AreEqual(expectedModel, privateObject.GetField("model"));
            Assert.AreEqual(expectedManufacturer, privateObject.GetField("manufacturer"));
            Assert.AreEqual(expectedColor, privateObject.GetField("color"));
            Assert.AreEqual(expectedSalePrice, privateObject.GetField("salePrice"));
        }
        #endregion

        #region Method Test
        [TestMethod]
        public void ToString_Return_VehicleStringRepresentation()
        {
            // Arrange
            int year = 2020;
            string model = "Corolla";
            string manufacturer = "Toyota";
            PaintColor color = PaintColor.Sienna;
            decimal salePrice = 20000m;

            // Act
            Vehicle vehicle = new Vehicle(year, model, manufacturer, color, salePrice);
            string vehicleString = vehicle.ToString();

            // Assert
            Assert.AreEqual($"{year}, {manufacturer}, {model}, {color}", vehicleString);
        } 
        #endregion

        #region Helper Methods

        /// <summary>
        /// Helper method to obtain only the message from an Exception object.
        /// </summary>
        /// <param name="exceptionMessage">The Exception's Message state.</param>
        /// <returns>The Exception's message with the parameter omitted.</returns>
        /// <remarks>
        /// The Exception.Message property returns the Exception's message on line 1 and
        /// the parameter name on line 2. This method reads the first line and returns
        /// the message.
        /// </remarks>
        private string GetExceptionMessage(string exceptionMessage)
        {
            return new System.IO.StringReader(exceptionMessage).ReadLine();
        }
        #endregion







    }
}
